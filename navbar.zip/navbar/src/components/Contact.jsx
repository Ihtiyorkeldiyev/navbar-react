import React from 'react'

const Contact = () => {
  return (
      <div className= "d-flex align-items-center justify-content-center">
    <div className='text-center mt-5 w-50'> 
        <h5>Contact</h5>
    <p>
    hello Lorem ipsum dolor sit amet consectetur, adipisicing elit. Cum tempora, placeat tempore eius suscipit numquam sunt reiciendis quos molestiae impedit voluptatibus, assumenda quaerat ad earum dolorem necessitatibus ipsa rerum nemo?
        </p></div>
      </div>
  )
}

export default Contact